import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes, RouterLinkActive } from '@angular/router';

import { AppComponent } from './app.component';
import { ContactinformationComponent } from './contactinformation/contactinformation.component';

import {ContactService} from './services/contactinformation.service';

const appRoutes: Routes = [
    
    { path: 'contactinformation', component: ContactinformationComponent },   
    { path: '**', component: ContactinformationComponent },
    { path: '', component: ContactinformationComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    ContactinformationComponent
  ],
  imports: [
      RouterModule.forRoot(appRoutes), BrowserModule, FormsModule, ReactiveFormsModule, HttpModule
  ],
  providers: [ContactService],
  bootstrap: [AppComponent]
})
export class AppModule { }
