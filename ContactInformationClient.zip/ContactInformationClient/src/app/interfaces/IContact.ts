﻿export interface IContact {
    ContactID: number;
    FirstName: string;
    LastName: string;
    Email: string;
    PhoneNo: string;
    IsActive: boolean;

}


