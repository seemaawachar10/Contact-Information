import { Component, OnInit } from '@angular/core';
import {IContact} from '../interfaces/IContact';
import {ContactService} from '../services/contactinformation.service';

@Component({
  selector: 'app-contactinformation',
  templateUrl: './contactinformation.component.html',
  styleUrls: ['./contactinformation.component.css']
})
export class ContactinformationComponent implements OnInit {

    title: string = "Add New Contact";
    isAdd: boolean = true;
    public formSubmitAttempt: boolean = true;
    allContacts: IContact[];
    currentContact: IContact = { ContactID:0, FirstName:"", LastName:"", Email:"", IsActive:true,PhoneNo:"" };
    constructor(private _contactService: ContactService) { }

    ngOnInit() {
        this.getAllContacts();
       
    }

    getAllContacts() {
        this._contactService.getAllContacts().subscribe(
            (data => this.allContacts = data.json())
        );
    }
    onSubmit() {
        this.formSubmitAttempt = true;

        if (this.isAdd) {
            this._contactService.addContact(this.currentContact).subscribe(data => {
                
                if (data.status == 201) {
                    alert("Contact saved successfully");
                    this.getAllContacts();
                    this.resetCurrentContact();
                }
            });
        }
        else {
            this._contactService.editContact(this.currentContact.ContactID, this.currentContact).subscribe(
                data => {
                    if (data.status == 200) {
                        alert("Contact updated successfully");
                        this.getAllContacts();
                        this.resetCurrentContact();
                    }
                }

            );
        }

    }
    onEdit(contact: IContact) {
        this.currentContact = contact;
        this.title = "Edit contact";
        this.isAdd = false;
      
        //this.currentContact = { ContactID: 0, FirstName: "", LastName: "", Email: "", IsActive: true, PhoneNo: "" };
    }
    onActiveInactive(contact: IContact) {
        this._contactService.activeInactiveContact(contact.ContactID, contact).subscribe(
            data => {
                if (data.status == 200) {
                    if (contact.IsActive) {
                        alert("Contact activated");
                    }
                    else {
                        alert("Contact inactivated");
                    }
                    this.getAllContacts();
                    
                }
            }
        );
    }

    resetCurrentContact() {
        this.title = "Add New Contact";
        this.currentContact = { ContactID: 0, FirstName: "", LastName: "", Email: "", IsActive: true, PhoneNo: "" };
        this.isAdd = true;
        this.formSubmitAttempt = false;
    }

}
