﻿/// <reference path="../interfaces/icontact.ts" />
import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions, RequestMethod } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import {  IContact } from '../interfaces/IContact';
import "rxjs/Rx";
import { map } from "rxjs/operators";
@Injectable()
export class ContactService {
    private _URL = "http://localhost:8181/api/Contact";

    constructor(private http: Http) {
    }
    private handleError(error: Response) {

        //return Observable.throw(error.statusText);
    }
    getAllContacts() {

        return this.http.get(this._URL);
            
    }

    getContactByID(id: number) {

        return this.http.get(this._URL + "/" + id);
    }

    addContact(newContact: IContact) {
        var body = JSON.stringify(newContact);

        var headerOptions = new Headers({ 'Content-Type': 'application/json' });

        return this.http.post(this._URL, body, { headers: headerOptions }).pipe(
          
        );
    }
    editContact(id: number, Contact: IContact) {
        
        var body = JSON.stringify(Contact);
        var headerOptions = new Headers({ 'Content-Type': 'application/json; charset=UTF-8' });
     
        return this.http.put(this._URL + "/" + id, body, { headers: headerOptions }).pipe();
    }

    activeInactiveContact(id: number, Contact: IContact) {
       
        var body = JSON.stringify(Contact);
        var headerOptions = new Headers({ 'Content-Type': 'application/json' });
        

        
        return this.http.put(this._URL + "/ActiveInactiveContact/" + id, body, { headers: headerOptions });
    }

}
