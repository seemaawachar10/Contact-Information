﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ContactInformationAPI;
using ContactInformationAPI.Controllers;
using ContactInformationAPI.Models;
using System.Web.Http.Results;
using System.Net;

namespace ContactInformationAPI.Tests.Controllers
{
    [TestClass]
    public class ContactsControllerTest
    {

        ContactController controller = new ContactController();
        [TestMethod]
        public void Get()//Should return all contact
        {
            //Arrange
            


           // controller.PostContact(new Contact { ContactID = 1, FirstName = "Seema", LastName = "Awachar", Email = "seemaawachar10@gmail.com", PhoneNo = "+91-7709625925", IsActive = true });


            // Act
            IEnumerable<Contact> result = controller.GetContacts();

            // Assert
            Assert.IsNotNull(result);
          
        }

        [TestMethod]
        public void GetById()
        {
            var result = controller.GetContact(1) as OkNegotiatedContentResult<Contact>;

            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Content.ContactID);
        }

        [TestMethod]
        public void Post()
        {

            var item = GetDemocontact();
            var result = controller.PostContact(item) as CreatedAtRouteNegotiatedContentResult<Contact>;

            Assert.IsNotNull(result);
            Assert.AreEqual(result.RouteName, "DefaultApi");
            
            Assert.AreEqual(result.Content.FirstName, item.FirstName);
        }

        [TestMethod]
        public void Put_EditContact()
        {
            var item = GetDemocontact();
            item.FirstName = "Seema_Edited";
            var result = controller.PutContact(item.ContactID, item) as StatusCodeResult;
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(StatusCodeResult));
            Assert.AreEqual(HttpStatusCode.NoContent, result.StatusCode);
           
        }

        [TestMethod]
        public void Put_ActiveInactive()
        {
           // var item = GetDemocontact();
           var item= controller.GetContact(1) as OkNegotiatedContentResult<Contact>;
            bool prevVal = item.Content.IsActive;
            var result = controller.ActiveInactiveContact(item.Content.ContactID)  as OkNegotiatedContentResult<Contact>; ;
            Assert.IsNotNull(result);
            
            Assert.AreEqual(!prevVal, result.Content.IsActive);
        }


        Contact GetDemocontact()
        {
            return new Contact
            {
                ContactID = 3,
                FirstName = "Seema",
                LastName = "Awachar",
                Email = "seemaawachar10@gmail.com",
                PhoneNo = "+91-7709625925",
                IsActive = true
            };
        }
    }
}
