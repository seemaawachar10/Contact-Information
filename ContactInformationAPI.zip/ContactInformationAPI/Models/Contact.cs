﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ContactInformationAPI.Models
{
    public class Contact
    {
        [Key]
        public int ContactID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string PhoneNo { get; set; }//phone number can have - in between numbers and storing that number with - in db. So keeping datatype string
        public bool IsActive { get; set; }// Renaming Status mention in pdf to IsActive , 

    }

    
}