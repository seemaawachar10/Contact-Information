﻿using ContactInformationAPI.Models;
using ContactInformationAPI.Repository;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

namespace ContactInformationAPI.Controllers
{
    public class ContactController : ApiController
    {

        private ContactRepository repository = new ContactRepository();

        // GET: api/Contact
        public IQueryable<Contact> GetContacts()
        {
            return repository.GetContacts();
        }

        // GET: api/Contact/5
        [ResponseType(typeof(Contact))]
        public IHttpActionResult GetContact(int id)
        {

            if (!repository.ContactExists(id))
            {
                return NotFound();
            }

            return Ok(repository.getContact(id));
        }


        // POST: api/Contact
        [ResponseType(typeof(Contact))]
        public IHttpActionResult PostContact(Contact con)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
           con= repository.AddContact(con);
           

            return CreatedAtRoute("DefaultApi", new { id = con.ContactID }, con);
        }


        // PUT: api/Contact/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutContact(int id, Contact Contact)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != Contact.ContactID)
            {
                return BadRequest();
            }

          

            try
            {
                repository.EditContact(Contact);
                return StatusCode(HttpStatusCode.OK);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!repository.ContactExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }

                return StatusCode(HttpStatusCode.NoContent);
            }

            
        }


        // PUT: api/Contact/5
        [HttpPut]
        [ Route("api/Contact/ActiveInactiveContact/{id}")]
        [ResponseType(typeof(Contact))]
        
        public IHttpActionResult ActiveInactiveContact(int id)
        {
            
            if (!repository.ContactExists(id))
            {
                return NotFound();
            }
            
            return Ok(repository.ActiveOrInactiveContact(id));
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                repository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
