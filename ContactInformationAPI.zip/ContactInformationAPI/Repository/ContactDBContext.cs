﻿using ContactInformationAPI.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace ContactInformationAPI.Repository
{
    public class ContactDBContext:DbContext, IContactDBContext
    {
        public ContactDBContext() : base("name=ContactDBContext") 
        {
        }
        public DbSet<Contact> Contacts { get; set; }

        public void MarkAsModified(Contact item)
        {
            Entry(item).State = EntityState.Modified;
        }
    }
}