﻿using ContactInformationAPI.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactInformationAPI.Repository
{
    interface IContactDBContext : IDisposable
    {
        DbSet<Contact> Contacts { get; }
        int SaveChanges();
        void MarkAsModified(Contact item);
    }
}
