﻿using ContactInformationAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ContactInformationAPI.Repository
{
    public class ContactRepository
    {
        private ContactDBContext ContactDBContext = new ContactDBContext();

        public IQueryable<Contact> GetContacts()
        {
            return ContactDBContext.Contacts;
        }

        public Contact getContact(int id)
        {
          return  ContactDBContext.Contacts.Find(id);
        }

        public Contact AddContact(Contact con)
        {
            try
            {
                ContactDBContext.Contacts.Add(con);
                ContactDBContext.SaveChanges();
            }
            catch
            {
                throw;
            }
            return con;
        }

        public void EditContact(Contact con)
        {
            try
            {
                ContactDBContext.MarkAsModified(con);
                ContactDBContext.SaveChanges();
            }
            catch
            {
                throw;
            }
            
        }

        public bool ContactExists(int id)
        {
            return ContactDBContext.Contacts.Count(e => e.ContactID == id) > 0;
        }

        public Contact ActiveOrInactiveContact(int id)
        {
            Contact con = ContactDBContext.Contacts.Find(id);
            try
            {
                
                con.IsActive = !con.IsActive;

                ContactDBContext.MarkAsModified(con);
                ContactDBContext.SaveChanges();

            }
            catch
            {
                throw;
            }
            return con;
        }

        public void Dispose()
        {
            
                ContactDBContext.Dispose();
         
           
        }

    }
}